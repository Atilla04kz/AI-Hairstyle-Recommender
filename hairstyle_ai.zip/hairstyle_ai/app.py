import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import mediapipe as mp
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# === Page config and custom style ===
st.set_page_config(page_title="AI Hairstyle Recommender", layout="centered")

st.markdown("""
    <style>
        body, .stApp {
            background-color: #ffe4ec;
            color: #2e2e2e;
        }
        .stButton>button {
            background-color: #d63384;
            color: white;
            border: none;
            padding: 0.5em 1.2em;
            border-radius: 8px;
            font-size: 16px;
        }
        .stSelectbox label, .stFileUploader label {
            font-weight: 600;
            color: #6c1e4d;
        }
        .stTitle {
            color: #aa145c;
        }
        .block-container {
            padding-top: 2rem;
        }
    </style>
""", unsafe_allow_html=True)

# === Face shape detection ===
def get_face_shape(image_np):
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(static_image_mode=True)
    results = face_mesh.process(image_np)

    if not results.multi_face_landmarks:
        return None

    landmarks = results.multi_face_landmarks[0].landmark
    chin = np.array([landmarks[152].x, landmarks[152].y])
    left_cheek = np.array([landmarks[234].x, landmarks[234].y])
    right_cheek = np.array([landmarks[454].x, landmarks[454].y])
    forehead = np.array([landmarks[10].x, landmarks[10].y])

    jaw_width = np.linalg.norm(left_cheek - right_cheek)
    face_length = np.linalg.norm(forehead - chin)
    ratio = jaw_width / face_length

    st.info(f"Jaw-to-face-length ratio: **{ratio:.2f}**")

    if ratio < 0.75:
        return "Сердцеобразное"
    elif 0.75 <= ratio < 0.85:
        return "Овальное"
    elif 0.85 <= ratio < 1.0:
        return "Круглое"
    else:
        return "Квадратное"
        
# === Load and train model ===
df = pd.read_csv("recommendations.csv")

le_gender = LabelEncoder()
le_face = LabelEncoder()
le_type = LabelEncoder()
le_length = LabelEncoder()
le_style = LabelEncoder()

df["gender_enc"] = le_gender.fit_transform(df["gender"])
df["face_shape_enc"] = le_face.fit_transform(df["face_shape"])
df["hair_type_enc"] = le_type.fit_transform(df["hair_type"])
df["hair_length_enc"] = le_length.fit_transform(df["hair_length"])
df["hairstyle_enc"] = le_style.fit_transform(df["hairstyle"])

X = df[["gender_enc", "face_shape_enc", "hair_type_enc", "hair_length_enc"]]
y = df["hairstyle_enc"]

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)
model = DecisionTreeClassifier()
model.fit(X_train, y_train)

# === Interface ===
st.title("AI Hairstyle Recommender")

with st.container():
    gender = st.selectbox("Select Gender", le_gender.classes_)
    hair_type = st.selectbox("Select Hair Type", le_type.classes_)
    hair_length = st.selectbox("Select Hair Length", le_length.classes_)

st.subheader("Upload a face photo")
uploaded = st.file_uploader("Supported formats: JPG, JPEG, PNG", type=["jpg", "jpeg", "png"])

if uploaded:
    image = Image.open(uploaded).convert("RGB")
    st.image(image, caption="Uploaded Image", use_column_width=True)
    image_np = np.array(image)

    face_shape = get_face_shape(image_np)

    if face_shape:
        st.success(f"Detected face shape: **{face_shape}**")
        if st.button("Recommend Hairstyle"):
            input_data = [[
                le_gender.transform([gender])[0],
                le_face.transform([face_shape])[0],
                le_type.transform([hair_type])[0],
                le_length.transform([hair_length])[0]
            ]]
            prediction = model.predict(input_data)[0]
            predicted_hairstyle = le_style.inverse_transform([prediction])[0]
            st.success(f"Recommended Hairstyle: **{predicted_hairstyle}**")
    else:
        st.error("Face not detected. Please try another image.")
