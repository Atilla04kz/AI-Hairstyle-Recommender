import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
import joblib

# Загрузка данных
df = pd.read_csv("recommendations.csv")

# Кодирование категориальных признаков
le_gender = LabelEncoder()
le_face = LabelEncoder()
le_type = LabelEncoder()
le_length = LabelEncoder()
le_style = LabelEncoder()

X = pd.DataFrame({
    "gender": le_gender.fit_transform(df["gender"]),
    "face_shape": le_face.fit_transform(df["face_shape"]),
    "hair_type": le_type.fit_transform(df["hair_type"]),
    "hair_length": le_length.fit_transform(df["hair_length"]),
})
y = le_style.fit_transform(df["hairstyle"])

# Обучение модели
model = DecisionTreeClassifier()
model.fit(X, y)

# Сохранение модели и энкодеров
joblib.dump((model, le_gender, le_face, le_type, le_length, le_style), "model.pkl")
