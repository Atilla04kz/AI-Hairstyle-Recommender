import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder

# === Page Config and Style ===
st.set_page_config(page_title="AI Hairstyle Models", layout="centered")
st.markdown("""
    <style>
        body, .stApp {
            background-color: #fdf6f9;
            color: #2b2b2b;
        }
        .stButton>button {
            background-color: #c94077;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 0.5em 1em;
            font-size: 15px;
        }
        .stSidebar > div {
            background-color: #f9e9f1;
        }
        .stTitle {
            color: #9b2d50;
        }
        .stSelectbox label {
            color: #6c1e4d;
            font-weight: 600;
        }
        .stSubheader {
            color: #9b2d50;
        }
    </style>
""", unsafe_allow_html=True)

# === Load data ===
st.title("AI Algorithms for Hairstyle Recommendation")

df = pd.read_csv("recommendations.csv")

# Encoding
le_gender = LabelEncoder()
le_face = LabelEncoder()
le_type = LabelEncoder()
le_length = LabelEncoder()
le_style = LabelEncoder()

df["gender_enc"] = le_gender.fit_transform(df["gender"])
df["face_shape_enc"] = le_face.fit_transform(df["face_shape"])
df["hair_type_enc"] = le_type.fit_transform(df["hair_type"])
df["hair_length_enc"] = le_length.fit_transform(df["hair_length"])
df["hairstyle_enc"] = le_style.fit_transform(df["hairstyle"])

X = df[["gender_enc", "face_shape_enc", "hair_type_enc", "hair_length_enc"]]
y = df["hairstyle_enc"]

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# Sidebar input
st.sidebar.header("Input Parameters")
gender = st.sidebar.selectbox("Gender", le_gender.classes_)
face_shape = st.sidebar.selectbox("Face Shape", le_face.classes_)
hair_type = st.sidebar.selectbox("Hair Type", le_type.classes_)
hair_length = st.sidebar.selectbox("Hair Length", le_length.classes_)

input_vector = np.array([[le_gender.transform([gender])[0],
                          le_face.transform([face_shape])[0],
                          le_type.transform([hair_type])[0],
                          le_length.transform([hair_length])[0]]])

# === Level A Algorithms ===
if st.button("Run All Supervised Models"):
    st.subheader("Classification Models")
    classifiers = {
        "Linear Regression": LinearRegression(),
        "Logistic Regression": LogisticRegression(),
        "Decision Tree": DecisionTreeClassifier(),
        "Random Forest": RandomForestClassifier(),
        "Naive Bayes": GaussianNB(),
        "KNN": KNeighborsClassifier(),
        "SVM": SVC(),
        "Gradient Boosting": GradientBoostingClassifier()
    }

    model_predictions = {}

    for name, clf in classifiers.items():
        try:
            clf.fit(X_train, y_train)
            prediction = clf.predict(input_vector)[0]

            if name == "Linear Regression":
                prediction = int(round(prediction))
                prediction = np.clip(prediction, 0, len(le_style.classes_) - 1)

            pred_name = le_style.inverse_transform([int(prediction)])[0]
            acc = accuracy_score(
                y_test,
                clf.predict(X_test).round().astype(int) if name == "Linear Regression" else clf.predict(X_test)
            )

            model_predictions[name] = pred_name
            st.success(f"{name}: {pred_name} (Accuracy: {acc:.2f})")
        except Exception as e:
            st.warning(f"{name} Error: {e}")

    # Bar Chart of Predictions
    if model_predictions:
        st.subheader("Model Prediction Comparison")
        fig, ax = plt.subplots()
        model_names = list(model_predictions.keys())
        predictions = list(model_predictions.values())
        ax.bar(model_names, range(len(predictions)), tick_label=predictions)
        ax.set_ylabel("Model Index")
        ax.set_title("Predicted Hairstyles by Model")
        plt.xticks(rotation=45, ha='right')
        st.pyplot(fig)

# === Level B Algorithms ===
if st.button("Run All Unsupervised Models"):
    st.subheader("Unsupervised Learning")

    # KMeans
    kmeans = KMeans(n_clusters=3, random_state=42)
    kmeans.fit(X)
    cluster = kmeans.predict(input_vector)[0]
    st.info(f"K-Means Cluster: #{cluster + 1}")

    # PCA
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)
    user_pca = pca.transform(input_vector)
    st.info(f"PCA Components: {user_pca[0][0]:.2f}, {user_pca[0][1]:.2f}")

    # Apriori
    df_apr = df[["gender", "face_shape", "hair_type", "hair_length", "hairstyle"]].astype(str)
    transactions = df_apr.values.tolist()
    te = TransactionEncoder()
    df_trans = pd.DataFrame(te.fit_transform(transactions), columns=te.columns_)
    freq = apriori(df_trans, min_support=0.1, use_colnames=True)
    rules = association_rules(freq, metric="lift", min_threshold=1)

    st.write("Frequent Association Rules:")
    if not rules.empty:
        for i, row in rules.head(3).iterrows():
            lhs = ', '.join(row['antecedents'])
            rhs = ', '.join(row['consequents'])
            st.write(f"If {lhs} → then {rhs} (support: {row['support']:.2f})")
    else:
        st.warning("No frequent rules found.")

    # PCA + KMeans Clustering Plot
    st.subheader("Clustering Visualization (PCA + KMeans)")
    labels = kmeans.labels_
    centers_2d = pca.transform(kmeans.cluster_centers_)
    fig, ax = plt.subplots()
    ax.scatter(X_pca[:, 0], X_pca[:, 1], c=labels, cmap='viridis', alpha=0.6)
    ax.scatter(centers_2d[:, 0], centers_2d[:, 1], c='red', marker='X', s=200, label='Centers')
    ax.scatter(user_pca[0][0], user_pca[0][1], c='black', marker='*', s=200, label='You')
    ax.legend()
    st.pyplot(fig)
